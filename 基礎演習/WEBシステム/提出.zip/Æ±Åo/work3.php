<?php
     $get_val1 = $_GET['name'];
     $get_val2 = $_GET['data'];
    
     print($get_val1.'<br>');
     print($get_val2);
?>

