<?php
     $get_val1 = $_POST['name'];
     $get_val2 = $_POST['data'];
    
     print($get_val1.'<br>');
     print($get_val2);
?>

