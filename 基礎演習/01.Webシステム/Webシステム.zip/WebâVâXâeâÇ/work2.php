<html>
  <head>
    <font size="6">
      <center>
	情報システム基礎演習　学習演習ページ<br><br>
      </center>
    </font>
  </head>
  <body>
    <?php
      $get_val1 = $_POST['name'];
      $get_val2 = $_POST['data'];
      print($get_val1.'<br>');
      print($get_val2);
    ?>
  </body>
</html>