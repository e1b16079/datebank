

   <html>
     <body>
        確認しました<br>

         <a href="http://150.89.223.72:443/work4.php" target="_blank">戻る</a>

     </body>
     
       <?php
         $get_val1 = $_POST['name'];
         $get_val2 = $_POST['data'];

         
           $fp = fopen('data.txt','w');

	   fwrite($fp,$get_val1);
           fwrite($fp,$get_val2);

	fclose($fp);

       ?>
    
