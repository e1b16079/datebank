        



       <html>

         <?php
           $fp = fopen('data.txt','r');
           while(!feof($fp)){
            $line = fgets($fp);
            print $line;
            print "<br>\n";
          }
       ?>

       <form action="kakunin.php" method="post">
          名前:<input type="text" name="name" />
          コメント:<input type="text" name="data" />
          <input value="送信" type="submit" />
         </form>
    
        </html>
